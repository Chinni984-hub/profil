const express = require('express');
const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.set('views', './views');
app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

let user = {
  firstName: 'Jordan',
  lastName: 'Dey',
  username: '@jordan.dey',
  email: 'jordan.dey@email.com',
  bio: 'Full-stack developer passionate about clean UI.',
  location: 'Hyderabad, India',
  website: 'https://jordandey.dev',
  connections: {
    google:    { connected: true,  detail: 'jordan.dey@gmail.com' },
    github:    { connected: false, detail: '' },
    slack:     { connected: false, detail: '' },
    figma:     { connected: true,  detail: 'Synced 2h ago' },
    instagram: { connected: false, detail: '' },
    whatsapp:  { connected: false, detail: '' },
    twitter:   { connected: false, detail: '' },
    linkedin:  { connected: false, detail: '' },
    discord:   { connected: false, detail: '' },
    spotify:   { connected: false, detail: '' },
    youtube:   { connected: false, detail: '' },
    telegram:  { connected: false, detail: '' }
  },
  settings: {
    emailNotifications: true,
    pushNotifications: false,
    weeklyDigest: true,
    publicProfile: true,
    activityVisibility: false,
    twoFactor: false,
    loginAlerts: true,
    dataSharing: false,
    theme: 'light',
    accentColor: 'purple',
    fontSize: 'medium',
    language: 'en'
  }
};

app.get('/', (req, res) => res.redirect('/profile/info'));

app.get('/profile/:tab', (req, res) => {
  const tab = req.params.tab;
  const validTabs = ['info', 'settings', 'connections', 'logout', 'terminate'];
  if (!validTabs.includes(tab)) return res.redirect('/profile/info');
  res.render('profile', { user, activeTab: tab, message: null });
});

app.post('/profile/info', (req, res) => {
  const { firstName, lastName, username, email, bio, location, website } = req.body;
  user = { ...user, firstName, lastName, username, email, bio, location, website };
  res.render('profile', { user, activeTab: 'info', message: { type: 'success', text: 'Profile updated successfully.' } });
});

app.post('/profile/settings', (req, res) => {
  user.settings = {
    emailNotifications: !!req.body.emailNotifications,
    pushNotifications:  !!req.body.pushNotifications,
    weeklyDigest:       !!req.body.weeklyDigest,
    publicProfile:      !!req.body.publicProfile,
    activityVisibility: !!req.body.activityVisibility,
    twoFactor:          !!req.body.twoFactor,
    loginAlerts:        !!req.body.loginAlerts,
    dataSharing:        !!req.body.dataSharing,
    theme:       req.body.theme       || 'light',
    accentColor: req.body.accentColor || 'purple',
    fontSize:    req.body.fontSize    || 'medium',
    language:    req.body.language    || 'en'
  };
  res.render('profile', { user, activeTab: 'settings', message: { type: 'success', text: 'Settings saved successfully.' } });
});

app.post('/profile/connections/:name', (req, res) => {
  const name = req.params.name;
  if (user.connections[name] !== undefined) {
    user.connections[name].connected = !user.connections[name].connected;
    if (user.connections[name].connected) {
      const defaults = {
        google:    'jordan.dey@gmail.com',
        github:    'github.com/jordandey',
        slack:     'Jordan @ Dev Workspace',
        figma:     'Synced just now',
        instagram: '@jordan.dey',
        whatsapp:  '+91 98765 43210',
        twitter:   '@jordandey',
        linkedin:  'linkedin.com/in/jordandey',
        discord:   'jordandey#1234',
        spotify:   'Jordan Dey',
        youtube:   '@jordandey',
        telegram:  '@jordandey'
      };
      user.connections[name].detail = defaults[name] || 'Connected';
    }
  }
  res.redirect('/profile/connections');
});

app.post('/profile/logout', (req, res) => {
  res.render('profile', { user, activeTab: 'logout', message: { type: 'info', text: 'You have been logged out successfully.' } });
});

app.post('/profile/terminate', (req, res) => {
  res.render('profile', { user, activeTab: 'terminate', message: { type: 'danger', text: 'Account termination requested. A confirmation email has been sent.' } });
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
