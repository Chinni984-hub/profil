# User Profile Page — Node.js App

A full-featured user profile web application built with **Node.js**, **Express**, and **EJS**.

## Features
- Modify user information (name, email, bio, location, website)
- Settings panel with toggle switches (notifications, privacy)
- Connections management (Google, GitHub, Slack, Figma)
- Log out page
- Terminate account with danger confirmation cards

## Tech Stack
- **Node.js** + **Express** — server & routing
- **EJS** — server-side HTML templating
- **Plain CSS** — custom styling, responsive layout

## Getting Started

### 1. Install dependencies
```bash
npm install
```

### 2. Run the server
```bash
node server.js
```

### 3. Open in browser
```
http://localhost:3000
```

## Project Structure
```
profile-app/
├── server.js           # Express app & routes
├── views/
│   └── profile.ejs     # EJS template
├── public/
│   └── css/
│       └── style.css   # Stylesheet
└── package.json
```

## Routes
| Method | Path | Description |
|--------|------|-------------|
| GET | `/profile/:tab` | Render a tab (info, settings, connections, logout, terminate) |
| POST | `/profile/info` | Save user info |
| POST | `/profile/settings` | Save settings |
| POST | `/profile/connections/:name` | Toggle a connection |
| POST | `/profile/logout` | Log out action |
| POST | `/profile/terminate` | Terminate account action |
